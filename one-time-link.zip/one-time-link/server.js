const express = require('express');
const crypto = require('crypto');
const app = express();
const PORT = process.env.PORT || 3000;

// ============ ENCRYPTION SETUP ============
// In production, store this in environment variables!
// Generate with: node -e "console.log(crypto.randomBytes(32).toString('hex'))"
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || crypto.randomBytes(32).toString('hex');
const ALGORITHM = 'aes-256-gcm';

// Convert hex key to buffer
const keyBuffer = Buffer.from(ENCRYPTION_KEY, 'hex');

// ============ ENCRYPTION FUNCTIONS ============
function encryptText(text) {
  // Generate a random initialization vector (IV)
  const iv = crypto.randomBytes(16);
  
  // Create cipher
  const cipher = crypto.createCipheriv(ALGORITHM, keyBuffer, iv);
  
  // Encrypt the text
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  // Get the authentication tag
  const authTag = cipher.getAuthTag();
  
  // Return combined data
  return {
    iv: iv.toString('hex'),
    encrypted: encrypted,
    authTag: authTag.toString('hex')
  };
}

function decryptText(encryptedData) {
  try {
    const iv = Buffer.from(encryptedData.iv, 'hex');
    const authTag = Buffer.from(encryptedData.authTag, 'hex');
    const encrypted = encryptedData.encrypted;
    
    // Create decipher
    const decipher = crypto.createDecipheriv(ALGORITHM, keyBuffer, iv);
    decipher.setAuthTag(authTag);
    
    // Decrypt
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    console.error('Decryption failed:', error.message);
    return null;
  }
}

// ============ STORAGE ============
// In-memory storage
const storage = new Map();
const rateLimit = new Map();
const csrfTokens = new Map();

// Middleware
app.use(express.json());
app.use(express.static('public'));

// ============ SECURITY HEADERS ============
app.use((req, res, next) => {
  res.set({
    'X-Frame-Options': 'DENY',
    'X-Content-Type-Options': 'nosniff',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline';",
    'Cache-Control': 'no-store, no-cache, must-revalidate, private',
    'Pragma': 'no-cache'
  });
  next();
});

// ============ ORIGIN VALIDATION MIDDLEWARE ============
app.use((req, res, next) => {
  if (!req.path.startsWith('/api/')) {
    return next();
  }

  const origin = req.headers.origin;
  const referer = req.headers.referer;
  const host = req.get('host');
  
  const allowedOrigins = [
    `http://localhost:${PORT}`,
    `https://localhost:${PORT}`,
  ];
  
  if (origin) {
    const isAllowed = allowedOrigins.some(allowed => 
      origin === allowed || origin.startsWith(allowed)
    );
    
    if (!isAllowed && process.env.NODE_ENV === 'production') {
      return res.status(403).json({ 
        error: 'Origin not allowed'
      });
    }
  }
  
  if (req.method === 'POST' || req.method === 'PUT' || req.method === 'DELETE') {
    const requestOrigin = origin || referer;
    if (requestOrigin) {
      let originDomain = requestOrigin;
      if (originDomain.includes('://')) {
        originDomain = originDomain.split('://')[1];
      }
      if (originDomain.includes('/')) {
        originDomain = originDomain.split('/')[0];
      }
      
      const isSameOrigin = originDomain === host || 
                          originDomain === `localhost:${PORT}` ||
                          originDomain === `127.0.0.1:${PORT}`;
      
      if (!isSameOrigin && process.env.NODE_ENV === 'production') {
        return res.status(403).json({ 
          error: 'Cross-site request blocked'
        });
      }
    }
  }
  
  next();
});

// ============ CSRF TOKEN GENERATION ============
app.get('/api/csrf-token', (req, res) => {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = Date.now() + 60 * 60 * 1000;
  
  csrfTokens.set(token, { expires, used: false });
  
  for (const [key, value] of csrfTokens) {
    if (Date.now() > value.expires) {
      csrfTokens.delete(key);
    }
  }
  
  res.json({ 
    csrfToken: token,
    expires: expires
  });
});

// ============ CSRF VALIDATION MIDDLEWARE ============
function validateCsrf(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next();
  }
  
  if (!req.path.startsWith('/api/')) {
    return next();
  }
  
  const csrfToken = req.headers['x-csrf-token'] || req.body._csrf;
  
  if (!csrfToken) {
    return res.status(403).json({ 
      error: 'CSRF token missing'
    });
  }
  
  const stored = csrfTokens.get(csrfToken);
  
  if (!stored || stored.used || Date.now() > stored.expires) {
    if (stored) csrfTokens.delete(csrfToken);
    return res.status(403).json({ 
      error: 'Invalid CSRF token'
    });
  }
  
  stored.used = true;
  csrfTokens.set(csrfToken, stored);
  
  next();
}

// ============ RATE LIMITING MIDDLEWARE ============
app.use('/api/consume', (req, res, next) => {
  const ip = req.ip || req.connection.remoteAddress || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 60 * 1000;
  const maxAttempts = 5;
  
  for (const [key, value] of rateLimit) {
    if (now > value.reset) {
      rateLimit.delete(key);
    }
  }
  
  if (!rateLimit.has(ip)) {
    rateLimit.set(ip, { count: 1, reset: now + windowMs });
    return next();
  }
  
  const data = rateLimit.get(ip);
  
  if (now > data.reset) {
    rateLimit.set(ip, { count: 1, reset: now + windowMs });
    return next();
  }
  
  if (data.count >= maxAttempts) {
    const timeLeft = Math.ceil((data.reset - now) / 1000);
    return res.status(429).json({ 
      success: false, 
      message: `Too many attempts. Wait ${timeLeft}s`,
      retryAfter: timeLeft
    });
  }
  
  data.count++;
  rateLimit.set(ip, data);
  next();
});

app.use('/api/generate', (req, res, next) => {
  const ip = req.ip || req.connection.remoteAddress || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 60 * 1000;
  const maxGenerates = 10;
  
  const genKey = `gen_${ip}`;
  
  for (const [key, value] of rateLimit) {
    if (now > value.reset && key.startsWith('gen_')) {
      rateLimit.delete(key);
    }
  }
  
  if (!rateLimit.has(genKey)) {
    rateLimit.set(genKey, { count: 1, reset: now + windowMs });
    return next();
  }
  
  const data = rateLimit.get(genKey);
  
  if (now > data.reset) {
    rateLimit.set(genKey, { count: 1, reset: now + windowMs });
    return next();
  }
  
  if (data.count >= maxGenerates) {
    const timeLeft = Math.ceil((data.reset - now) / 1000);
    return res.status(429).json({ 
      success: false, 
      message: `Too many links. Wait ${timeLeft}s`
    });
  }
  
  data.count++;
  rateLimit.set(genKey, data);
  next();
});

app.use('/api', validateCsrf);

// ============ API ENDPOINTS ============

// Generate a one-time link
app.post('/api/generate', (req, res) => {
  const { linkPassword, secretMessage, isPasswordless } = req.body;
  
  if (!isPasswordless && (!linkPassword || linkPassword.trim().length < 4)) {
    return res.status(400).json({ 
      success: false, 
      message: 'Password must be at least 4 characters' 
    });
  }
  
  if (!secretMessage || secretMessage.trim().length === 0) {
    return res.status(400).json({ 
      success: false, 
      message: 'Secret message is required' 
    });
  }
  
  if (secretMessage.length > 5000) {
    return res.status(400).json({ 
      success: false, 
      message: 'Secret too long (max 5000 characters)' 
    });
  }
  
  const token = crypto.randomUUID();
  const now = Date.now();
  const expiry = now + 60 * 60 * 1000;
  
  // Encrypt the secret before storing
  const encryptedSecret = encryptText(secretMessage.trim());
  
  let data = {
    secret: encryptedSecret, // Store encrypted
    expiry: expiry,
    used: false,
    passwordless: isPasswordless || false
  };
  
  if (!isPasswordless && linkPassword && linkPassword.trim() !== '') {
    const hash = crypto.createHash('sha256');
    hash.update(linkPassword.trim());
    data.hash = hash.digest('hex');
  } else {
    data.hash = null;
  }
  
  storage.set('ot_' + token, data);
  
  const url = `${req.protocol}://${req.get('host')}/?v=view&token=${encodeURIComponent(token)}`;
  
  res.json({ 
    success: true,
    link: url, 
    token: token, 
    expiry: expiry
  });
});

// Consume one-time link
app.post('/api/consume', (req, res) => {
  const { token, enteredPassword } = req.body;
  
  if (!token || token.trim() === '') {
    return res.status(400).json({ 
      success: false, 
      message: 'Invalid token' 
    });
  }
  
  const key = 'ot_' + token;
  const storedData = storage.get(key);
  
  if (!storedData) {
    return res.json({ 
      success: false, 
      message: 'Link not found or already used' 
    });
  }
  
  if (storedData.used === true) {
    storage.delete(key);
    return res.json({ 
      success: false, 
      message: 'This link has already been used' 
    });
  }
  
  const now = Date.now();
  if (now > storedData.expiry) {
    storage.delete(key);
    return res.json({ 
      success: false, 
      message: 'Link expired' 
    });
  }
  
  // Handle passwordless links
  if (storedData.passwordless === true) {
    storedData.used = true;
    storage.delete(key);
    
    // Decrypt the secret before sending
    const decryptedSecret = decryptText(storedData.secret);
    if (!decryptedSecret) {
      return res.json({ 
        success: false, 
        message: 'Error decrypting secret' 
      });
    }
    
    return res.json({ 
      success: true, 
      secret: decryptedSecret,
      message: 'Link verified!'
    });
  }
  
  // Verify password
  if (!enteredPassword || enteredPassword.trim() === '') {
    return res.status(400).json({ 
      success: false, 
      message: 'Please enter a password' 
    });
  }
  
  const hash = crypto.createHash('sha256');
  hash.update(enteredPassword.trim());
  const attemptHash = hash.digest('hex');
  
  if (!timingSafeCompare(attemptHash, storedData.hash)) {
    return res.json({ 
      success: false, 
      message: 'Incorrect password' 
    });
  }
  
  // SUCCESS! Mark as used and delete
  storedData.used = true;
  storage.delete(key);
  
  // Decrypt the secret before sending
  const decryptedSecret = decryptText(storedData.secret);
  if (!decryptedSecret) {
    return res.json({ 
      success: false, 
      message: 'Error decrypting secret' 
    });
  }
  
  res.json({ 
    success: true, 
    secret: decryptedSecret,
    message: 'Link verified!'
  });
});

// Check if link exists
app.post('/api/check', (req, res) => {
  const { token } = req.body;
  
  if (!token || token.trim() === '') {
    return res.json({ exists: false });
  }
  
  const key = 'ot_' + token;
  const storedData = storage.get(key);
  
  if (!storedData) {
    return res.json({ exists: false });
  }
  
  const now = Date.now();
  if (now > storedData.expiry || storedData.used === true) {
    storage.delete(key);
    return res.json({ exists: false });
  }
  
  res.json({ 
    exists: true,
    passwordless: storedData.passwordless || false
  });
});

// ============ HELPER FUNCTIONS ============

function timingSafeCompare(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') {
    return false;
  }
  
  if (a.length !== b.length) {
    return false;
  }
  
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
}

// Cleanup expired entries (run every hour)
setInterval(() => {
  const now = Date.now();
  const toDelete = [];
  
  for (const [key, value] of storage) {
    if (now > value.expiry || value.used === true) {
      toDelete.push(key);
    }
  }
  
  for (const key of toDelete) {
    storage.delete(key);
  }
  
  for (const [key, value] of rateLimit) {
    if (now > value.reset) {
      rateLimit.delete(key);
    }
  }
  
  for (const [key, value] of csrfTokens) {
    if (now > value.expires || value.used) {
      csrfTokens.delete(key);
    }
  }
}, 60 * 60 * 1000);

// ============ START SERVER ============
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🔐 Encryption: ${ALGORITHM} enabled`);
  console.log(`🔑 Encryption Key: ${ENCRYPTION_KEY.substring(0, 10)}... (${ENCRYPTION_KEY.length} chars)`);
  console.log(`📊 Rate limiting: 5 attempts/min (consume), 10/min (generate)`);
  console.log(`🔒 CSRF protection enabled`);
});