const express = require('express');
const crypto = require('crypto');
const app = express();
const PORT = process.env.PORT || 3000;

// In-memory storage (use a database in production)
const storage = new Map();

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Generate a one-time link
app.post('/api/generate', (req, res) => {
  const { linkPassword, secretMessage, isPasswordless } = req.body;
  
  const token = crypto.randomUUID();
  const now = Date.now();
  const expiry = now + 60 * 60 * 1000; // 1 hour
  
  let data = {
    secret: secretMessage,
    expiry: expiry,
    used: false,
    passwordless: isPasswordless || false
  };
  
  // Only hash password if not passwordless
  if (!isPasswordless && linkPassword && linkPassword.trim() !== '') {
    const hash = crypto.createHash('sha256');
    hash.update(linkPassword);
    data.hash = hash.digest('hex');
  } else {
    data.hash = null;
  }
  
  // Store in memory (use database in production)
  storage.set('ot_' + token, data);
  
  // Generate the URL
  const url = `${req.protocol}://${req.get('host')}/?v=view&token=${encodeURIComponent(token)}`;
  
  res.json({ 
    link: url, 
    token: token, 
    expiry: expiry 
  });
});

// Consume one-time link
app.post('/api/consume', (req, res) => {
  const { token, enteredPassword } = req.body;
  const key = 'ot_' + token;
  const storedData = storage.get(key);
  
  if (!storedData) {
    return res.json({ success: false, message: '❌ Link not found or already used' });
  }
  
  // Check if already used
  if (storedData.used === true) {
    storage.delete(key);
    return res.json({ success: false, message: '❌ This link has already been used' });
  }
  
  // Check expiry
  const now = Date.now();
  if (now > storedData.expiry) {
    storage.delete(key);
    return res.json({ success: false, message: '❌ Link expired (1 hour lifetime)' });
  }
  
  // Handle passwordless links
  if (storedData.passwordless === true) {
    storage.delete(key);
    return res.json({ 
      success: true, 
      secret: storedData.secret,
      message: '✅ Link verified! Your secret is below:'
    });
  }
  
  // Verify password
  if (!enteredPassword || enteredPassword.trim() === '') {
    return res.json({ success: false, message: '❌ Please enter a password' });
  }
  
  const hash = crypto.createHash('sha256');
  hash.update(enteredPassword);
  const attemptHash = hash.digest('hex');
  
  if (attemptHash !== storedData.hash) {
    return res.json({ success: false, message: '❌ Incorrect password' });
  }
  
  // SUCCESS!
  storage.delete(key);
  
  res.json({ 
    success: true, 
    secret: storedData.secret,
    message: '✅ Link verified! Your secret is below:'
  });
});

// Check if link exists
app.post('/api/check', (req, res) => {
  const { token } = req.body;
  const key = 'ot_' + token;
  const storedData = storage.get(key);
  
  if (!storedData) {
    return res.json({ exists: false });
  }
  
  const now = Date.now();
  if (now > storedData.expiry || storedData.used === true) {
    storage.delete(key);
    return res.json({ exists: false });
  }
  
  res.json({ 
    exists: true,
    passwordless: storedData.passwordless || false
  });
});

// Cleanup expired links (run every hour)
setInterval(() => {
  const now = Date.now();
  for (const [key, value] of storage) {
    if (now > value.expiry || value.used === true) {
      storage.delete(key);
    }
  }
}, 60 * 60 * 1000);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});